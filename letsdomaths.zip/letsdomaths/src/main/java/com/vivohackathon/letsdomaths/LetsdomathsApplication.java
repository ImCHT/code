package com.vivohackathon.letsdomaths;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LetsdomathsApplication {

	public static void main(String[] args) {
		SpringApplication.run(LetsdomathsApplication.class, args);
	}

}
